{
    'name': 'Board Management',
    'version': '1.0',
    'category': 'Management',
    'summary': 'Manage boards, meetings, and decisions',
    'author': 'Omar Fathy',
    'depends': ['base'],
    'data': [
        'security/security.xml',
        'security/ir.model.access.csv',
        'views/board_views.xml',
        'views/member_views.xml',
        'views/meeting_views.xml',
        'views/decision_views.xml',
        'views/report_meeting.xml',
    ],
    'installable': True,
    'application': True,
}
