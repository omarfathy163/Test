from odoo import models, fields

class BoardDecision(models.Model):
    _name = 'board.decision'
    _description = 'Board Decision'

    name = fields.Char(string='Decision Title')
    content = fields.Text(string='Decision Content')
    meeting_id = fields.Many2one('board.meeting', string='Related Meeting')
    responsible_id = fields.Many2one('res.users', string='Responsible')
    due_date = fields.Date(string='Due Date')
    status = fields.Selection([
        ('in_progress', 'In Progress'),
        ('done', 'Done'),
        ('postponed', 'Postponed'),
        ('rejected', 'Rejected')
    ], string='Status')

    vote_ids = fields.One2many('board.vote', 'decision_id', string='Votes')
