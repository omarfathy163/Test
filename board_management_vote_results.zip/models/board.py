from odoo import models, fields

class Board(models.Model):
    _name = 'board.management'
    _description = 'Board'

    name = fields.Char(string='Board Name', required=True)
    board_type = fields.Selection([
        ('executive', 'Executive'),
        ('supervisory', 'Supervisory'),
        ('internal_committee', 'Internal Committee')
    ], string='Board Type')
    description = fields.Text(string='Description')
    foundation_date = fields.Date(string='Foundation Date')
    secretary_id = fields.Many2one('res.users', string='Secretary')
    member_ids = fields.One2many('board.member', 'board_id', string='Members')
