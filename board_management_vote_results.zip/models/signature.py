
from odoo import models, fields

class BoardMeetingSignature(models.Model):
    _inherit = 'board.meeting'

    signature = fields.Binary(string="Signature")
