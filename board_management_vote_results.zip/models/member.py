from odoo import models, fields

class BoardMember(models.Model):
    _name = 'board.member'
    _description = 'Board Member'

    name = fields.Char(string='Member Name')
    role = fields.Selection([
        ('chairman', 'Chairman'),
        ('vice', 'Vice Chairman'),
        ('member', 'Member'),
        ('secretary', 'Secretary')
    ], string='Role')
    join_date = fields.Date(string='Join Date')
    status = fields.Selection([
        ('active', 'Active'),
        ('inactive', 'Inactive')
    ], string='Status')
    board_id = fields.Many2one('board.management', string='Board')
