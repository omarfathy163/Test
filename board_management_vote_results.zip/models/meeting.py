from odoo import models, fields

class BoardMeeting(models.Model):
    _name = 'board.meeting'
    _description = 'Board Meeting'

    name = fields.Char(string='Meeting Title')
    date = fields.Datetime(string='Meeting Date')
    location = fields.Char(string='Location')
    board_id = fields.Many2one('board.management', string='Related Board')
    agenda = fields.Text(string='Agenda')
    attendee_ids = fields.Many2many('board.member', string='Attendees')
    minutes = fields.Text(string='Meeting Minutes')
